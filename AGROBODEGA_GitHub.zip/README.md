# Documento de Arquitectura de Software (DAS)

**Proyecto:** AGROBODEGA  
**Arquitectos:** Kelly Fernanda Uribe Giraldo — Daniel Henao Londoño  
**Asignatura:** Ingeniería de Software II

---

## Control de cambios y revisiones

| Versión | Fecha | Tipo | Descripción | Autor |
|---------|-------|------|-------------|-------|
| 1 | 16/04/2026 | Creación | Versión inicial del documento | Kelly Uribe y Daniel Henao |

---

## Contenido

1. [Propósito del proyecto](#1-propósito-del-proyecto)
2. [Motivadores de la arquitectura](#2-motivadores-de-la-arquitectura)
   - 2.1 [Restricciones técnicas](#21-restricciones-técnicas)
   - 2.2 [Restricciones de negocio](#22-restricciones-de-negocio)
   - 2.3 [Atributos de calidad](#23-atributos-de-calidad)
   - 2.4 [Funcionalidades críticas](#24-funcionalidades-críticas)
3. [Tácticas y estrategias](#3-tácticas-y-estrategias)
4. [Modelo de contexto](#4-modelo-de-contexto)
5. [Arquetipo de solución/referencia](#5-arquetipo-de-soluciónreferencia)
6. [Arquitectura de solución/referencia](#6-arquitectura-de-soluciónreferencia)
7. [Línea base arquitectónica](#7-línea-base-arquitectónica)
   - 7.1 [Línea base de componentes](#71-línea-base-arquitectónica-de-componentes)
   - 7.2 [Estilos y patrones adoptados](#72-estilos-y-patrones-arquitectónicos-adoptados)
8. [Justificación alternativa de solución](#8-justificación-alternativa-de-solución)
9. [Vistas de arquitectura del sistema](#9-vistas-de-arquitectura-del-sistema)
   - 9.1 [Vista Funcional](#91-vista-funcional)
   - 9.3 [Vista de Despliegue](#93-vista-de-despliegue)

---

## 1. Propósito del proyecto

Para el **Administrador y propietario de bodega agrícola** que necesita sistematizar el registro de entradas y salidas de productos, ya que el manejo manual genera errores, pérdida de información y desorganización, afectando el control del inventario, la rentabilidad del negocio y la imagen de la bodega frente a cosecheros y negociantes, **AGROBODEGA** es un software de gestión para bodega agrícola que centraliza el control de inventario, movimientos y administración del negocio.

Permitirá al administrador tener control en tiempo real del movimiento de productos, mejorar la organización del negocio, reducir pérdidas por errores y facilitar el seguimiento de ingresos, gastos y rentabilidad. A diferencia de las soluciones actuales, AGROBODEGA estará diseñado específicamente para bodegas agrícolas locales, con trazabilidad completa y reportes automáticos de rentabilidad.

---

## 2. Motivadores de la arquitectura

Los motivadores de la arquitectura son el conjunto de restricciones técnicas, restricciones de negocio, atributos de calidad y funcionalidades críticas que condicionan y orientan las decisiones de diseño del sistema. En AGROBODEGA surgen del contexto real del negocio: presupuesto de $10.000.000 COP, equipo de dos estudiantes con carga académica, usuarios con distintos niveles tecnológicos, y operaciones transaccionales críticas que no pueden fallar.

### 2.1 Restricciones técnicas

| # | Categoría | Restricción | Justificación |
|---|-----------|-------------|---------------|
| 1 | Prácticas de diseño | Principios SOLID | Garantiza modularidad y mantenibilidad del sistema |
| 2 | Prácticas de diseño | Bajo acoplamiento y alta cohesión | Módulos independientes: inventario, entradas, salidas, reportes |
| 3 | Prácticas de diseño | Arquitectura en capas | Separa lógica de negocio, presentación y acceso a datos |
| 4 | Prácticas de diseño | Patrones GoF, GRASP, DRY y KISS | Estructuras organizadas y reutilizables |
| 5 | Código limpio | Clean Code, evitar Messy Code y Code Smells | Código claro y entendible para el equipo |
| 6 | DevOps | Prácticas DevOps de integración y despliegue | Cambios controlados, estabilidad en evolución |
| 7 | DevOps | 12 factores de aplicación (+ 3 extendidos) | Sistema configurable y desplegable en distintos entornos |
| 8 | Implementación | Scrum como metodología ágil | Iteraciones, entregas progresivas, adaptación a cambios |
| 9 | Implementación | Mecanismos de seguridad RBAC | Acceso controlado por rol, protección de datos sensibles |
| 10 | Desarrollo | Buenas prácticas de estructuración | Desarrollo organizado y mantenible |
| 11 | Desarrollo | Pruebas durante el desarrollo | Validación continua de entradas, salidas e inventario |
| 12 | Plataforma | Bases de datos relacionales para información transaccional | Consistencia entre productos, lotes, cosecheros y negociantes |

### 2.2 Restricciones de negocio

| # | Tipo | Restricción | Plan de acción |
|---|------|-------------|----------------|
| 1 | Humano | El propietario no participa en operaciones diarias | Funcionalidades de supervisión separadas de operación |
| 2 | Tiempo | Entradas y salidas deben registrarse en tiempo real | Captura rápida de datos, ningún movimiento pendiente |
| 3 | Legal | Cumplimiento Ley 1581 de protección de datos | Políticas de tratamiento, acceso por rol |
| 4 | Presupuesto | $10.000.000 COP máximo, sin ampliación inmediata | Planificación y monitoreo continuo de costos |
| 5 | Humano | Diferentes niveles de experiencia tecnológica | Flujos estructurados, campos definidos, UX simple |
| 6 | Humano | Operaciones según rol de usuario | Control de acceso RBAC en todos los módulos |
| 7 | Presupuesto | Costos adicionales requieren aprobación previa | Procedimiento formal de solicitud y aprobación |
| 8 | Humano | Equipo de dos estudiantes con carga académica | Cronograma realista, priorización de funcionalidades clave |

### 2.3 Atributos de calidad

Los atributos fueron priorizados mediante mapa de empatía con tres actores (administrador de bodega, propietario, administrador del sistema), con 14 atributos ponderados sobre 315 puntos.

| Prioridad | Atributo | Peso |
|-----------|----------|------|
| 1 | Confiabilidad | 10,48% |
| 2 | Disponibilidad | 9,84% |
| 3 | Usabilidad | 8,57% |
| 4 | Seguridad | 8,57% |
| 5 | Rendimiento | 7,94% |

#### 2.3.1 Atributo de calidad 1 — Confiabilidad (10,48%)

Garantiza que el sistema ejecute correctamente las operaciones principales, mantenga la integridad de la información durante los movimientos de inventario, evite registros inconsistentes, maneje errores de forma controlada y conserve la trazabilidad de todas las operaciones.

##### Característica 1 — CAR-CON-0001: Ejecución correcta de operaciones

| Escenario | Descripción |
|-----------|-------------|
| ESC-CAL-CON-0001 | Registro correcto de una entrada: valida datos, crea lote, actualiza stock y guarda de forma atómica |
| ESC-CAL-CON-0002 | Registro correcto de una salida: valida disponibilidad, descuenta stock y guarda en historial |
| ESC-CAL-CON-0003 | Consulta correcta del inventario: muestra estado actual por lote, producto, clasificación y cosechero sin inconsistencias |
| ESC-CAL-CON-0004 a CON-0023 | Actualización de inventario, conservación de lotes, consulta de historial, bloqueo por stock insuficiente, validaciones, manejo de errores, recuperación, estabilidad y trazabilidad |

##### Característica 2 — CAR-CON-0002 a 0007: Integridad, validación, manejo de errores, recuperación, estabilidad y trazabilidad

| Escenario | Descripción |
|-----------|-------------|
| ESC-CAL-CON-0004 | Actualización automática del inventario al registrar una entrada |
| ESC-CAL-CON-0005 | Descuento correcto del stock al registrar una salida |
| ESC-CAL-CON-0008 | Bloqueo del registro de salida cuando no existe stock suficiente |
| ESC-CAL-CON-0016 a CON-0023 | Recuperación tras reinicio, conservación del historial, asociación correcta usuario-operación |

#### 2.3.2 Atributo de calidad 2 — Disponibilidad (9,84%)

Garantiza que el sistema esté accesible en cualquier momento del día operativo, permitiendo registrar entradas y salidas sin interrupciones.

##### Característica 1 — CAR-DIS-0001: Disponibilidad del servicio

| Escenario | Descripción |
|-----------|-------------|
| ESC-CAL-DIS-0001 | Acceso correcto al sistema en cualquier momento para consultar o registrar |
| ESC-CAL-DIS-0002 | Registro de entradas en cualquier momento del día |
| ESC-CAL-DIS-0003 | Registro de salidas en cualquier momento del día |
| ESC-CAL-DIS-0004 a DIS-0008 | Consulta de inventario, restablecimiento sin inconsistencias, uso continuo, reanudación tras falla, prevención de datos incompletos |

##### Característica 2 — CAR-DIS-0002 a 0004: Disponibilidad cotidiana, recuperación y tolerancia a fallos

| Escenario | Descripción |
|-----------|-------------|
| ESC-CAL-DIS-0005 | Restablecimiento del inventario sin inconsistencias tras interrupción |
| ESC-CAL-DIS-0006 | Uso continuo prolongado sin interrupciones |
| ESC-CAL-DIS-0007 | Reanudación del acceso tras falla temporal sin pérdida de datos |
| ESC-CAL-DIS-0008 | Prevención de datos incompletos ante fallo durante registro |

### 2.4 Funcionalidades críticas

| RF | Funcionalidad | Táctica |
|----|---------------|---------|
| RF-16 | Registrar entrada con producto base, clasificación, cosechero, cantidad, lote y fecha | Operación transaccional ACID en capa de servicio |
| RF-17 | Crear lote y aumentar inventario automáticamente al registrar entrada válida | Gestión automática de lote e inventario en misma transacción |
| RF-18 | Registrar cobro por entrada y asociarlo a la entrada correspondiente | Cobro solo si existe entrada válida, misma transacción |
| RF-22 | Registrar salida con lote, cantidad, negociante y fecha | Validaciones de lote, cantidad y tercero en capa de servicio |
| RF-23 | Descuento automático del stock al registrar salida | Actualización atómica del inventario |
| RF-24 | Bloquear salidas cuando cantidad > stock del lote | Validación transaccional antes de permitir la operación |
| RF-25 | Registrar cobro por salida y asociarlo a la salida | Cobro dependiente de salida validada |
| RF-06 | Registrar productos base | Registro validado con información completa |
| RF-08 | Configurar clasificaciones por producto base | Estructura controlada para organizar inventario |
| RF-12 | Registrar cosecheros | Registro validado con trazabilidad del origen |
| RF-13 | Registrar negociantes con nombre, apellidos y teléfono | Registro validado para trazabilidad comercial |
| RF-29 | Consultar inventario por lotes | Consulta estructurada sobre la base de datos |

---

## 3. Tácticas y estrategias

| # | Táctica | Driver de calidad | Descripción |
|---|---------|-------------------|-------------|
| 1 | Operación transaccional ACID | Confiabilidad | Todas las operaciones críticas se ejecutan como transacciones atómicas en PostgreSQL con rollback completo ante fallo |
| 2 | Validación transaccional de stock | Confiabilidad | Antes de registrar una salida, se valida que la cantidad no supere el stock dentro de la misma transacción |
| 3 | Control de acceso RBAC | Seguridad | Spring Security valida el token JWT de Auth0 en cada solicitud, extrayendo el rol antes de permitir la operación |
| 4 | Caché con Redis | Rendimiento | Catálogos frecuentes (productos, clasificaciones, cosecheros, parámetros) se cachean en Redis reduciendo latencia |
| 5 | Configuración externalizada — Spring Cloud Config | Cap. ser administrado | Valores de comisión y umbrales de alerta se externalizan sin modificar código ni hacer redespliegue |
| 6 | Observabilidad — OpenTelemetry + Grafana | Disponibilidad / Soporte | Logs, métricas y trazas distribuidas en Grafana para detectar fallos antes de impactar la operación |
| 7 | Contenedores — Docker Compose | Cap. ser desplegado | Todos los servicios empaquetados en Docker para despliegue consistente y reproducible |
| 8 | CI/CD — GitHub Actions | Cap. ser probado y desplegado | Cada commit dispara compilación, pruebas, análisis estático y build de imagen Docker |
| 9 | Notificaciones asincrónicas — SendGrid | Usabilidad | Alertas de stock insuficiente y permanencia de lotes desacopladas de la lógica de negocio |

---

## 4. Modelo de contexto

Un modelo de contexto define los límites del sistema y sus relaciones con entidades externas de forma tecnológicamente agnóstica. Identifica actores, el sistema central y los servicios externos que consume.

**Actor:** Usuario Final (administrador de bodega, propietario, administrador del sistema) accede desde PC o laptop mediante Internet.

**Sistema central:** AGROBODEGA gestiona inventario por movimientos, cobros por entrada/salida, gastos operativos, reportes de rentabilidad y alertas operativas.

**Componentes externos:** API Gateway · Identity Provider · Notification Gateway · Componente de notificaciones · Web Application Firewall · Base de datos SQL · Caché distribuida · Catálogo de mensajes · Catálogo de parámetros · Catálogo de notificaciones · Baúl de secretos

![Diagrama de Contexto AGROBODEGA](diagramas/01_diagrama_contexto.png)

---

## 5. Arquetipo de solución/referencia

Un arquetipo de solución define la estructura general de forma agnóstica a tecnologías específicas. Representa los componentes necesarios y sus relaciones antes de comprometerse con un stack concreto.

| # | Componente | Rol | Justificación |
|---|-----------|-----|---------------|
| 1 | WAF | Primera línea de defensa perimetral | Protege contra SQL Injection, XSS y DDoS |
| 2 | Frontend (storage account) | Presentación web estática | Despliegue independiente del backend |
| 3 | API Gateway | Punto de entrada centralizado | Autenticación, enrutamiento, rate limiting, observabilidad |
| 4 | Identity Provider | Autenticación centralizada | Externaliza gestión de roles y tokens |
| 5 | Backend (container management) | Núcleo de lógica de negocio | Inventario, entradas, salidas, cobros, reportes |
| 6 | Base de datos SQL | Fuente de verdad transaccional ACID | Consistencia entre lotes, entradas, salidas y cobros |
| 7 | Caché | Almacenamiento en memoria de datos frecuentes | Reduce latencia sin sobrecargar la BD |
| 8 | Notification Gateway | Envío desacoplado de notificaciones | Sin impacto en latencia del sistema principal |
| 9 | Componente de notificaciones | Generación y despacho de alertas | Consume plantillas del Catálogo de notificaciones |
| 10 | Key Vault | Gestión centralizada de secretos | Ninguna credencial expuesta en código |
| 11 | Catálogo de parámetros | Valores configurables del negocio | Ajuste sin redespliegue |
| 12 | Catálogo de mensajes | Textos del sistema centralizados | Contenido separado de la lógica |
| 13 | Catálogo de notificaciones | Plantillas de alertas | Modificación sin tocar código |
| 14 | CI/CD Pipeline | Integración y despliegue continuo | Calidad garantizada en cada entrega |

![Arquetipo de Referencia AGROBODEGA](diagramas/02_arquetipo_referencia.png)

---

## 6. Arquitectura de solución/referencia

La arquitectura de solución concreta cada componente agnóstico en una tecnología específica, seleccionada considerando el presupuesto de $10.000.000 COP y preferencia por soluciones open source o freemium.

| Componente agnóstico | Tecnología concreta | Licencia |
|---------------------|--------------------|---------:|
| WAF | Cloudflare WAF | Freemium |
| Frontend | React 19 + TypeScript + Vite (Vercel) | Open Source |
| API Gateway | Kong Gateway | Apache 2.0 |
| Identity Provider | Auth0 (Okta) | Freemium (25k MAU) |
| Backend | Spring Boot 3 + Java 21 + Docker | Apache 2.0 |
| Base de datos | PostgreSQL 16 | Open Source |
| Caché | Redis Community 7.x | RSALv2 |
| Notification Gateway | SendGrid API v3 | Freemium (100 emails/día) |
| Key Vault | HashiCorp Vault Community | BSL |
| Catálogo de parámetros | Spring Cloud Config Server | Apache 2.0 |
| Catálogo de mensajes | Strapi Community 5.x | Open Source |
| Catálogo de notificaciones | Strapi Community 5.x | Open Source |
| Observabilidad | OpenTelemetry + Grafana Stack | Apache 2.0 |
| CI/CD Pipeline | GitHub Actions | Freemium (2.000 min/mes) |

![Arquitectura de Referencia AGROBODEGA](diagramas/03_arquitectura_referencia.png)

---

## 7. Línea base arquitectónica

La línea base arquitectónica es el conjunto de decisiones de diseño definitivas que establecen el punto de partida estable del sistema, incluyendo todos los componentes adoptados con sus versiones, relaciones y justificaciones técnicas.

### 7.1 Línea base arquitectónica de componentes

#### Componente 1 — agrobodega-backend v1.0.0-SNAPSHOT
**Tipo:** A desarrollar

Aplicación principal Spring Boot con arquitectura hexagonal: `domain` · `application` · `infrastructure` · `crosscutting`. Gestiona inventario, entradas, salidas, cobros, gastos, usuarios, cosecheros, negociantes, productos base, clasificaciones y reportes. API REST documentada con Springdoc OpenAPI y protegida con Spring Security + JWT de Auth0.

**Motivación:** Centraliza la lógica de negocio. La arquitectura hexagonal garantiza que las reglas de negocio no dependan de tecnologías externas, facilitando pruebas unitarias del dominio sin levantar bases de datos.

**Depende de:** Spring Boot 3.x · Spring Web · Spring Data JPA · Spring Security 6.x · Spring Cloud Config · PostgreSQL JDBC · Spring Data Redis · Java 21 · Auth0 · Springdoc OpenAPI

#### Componente 2 — Plataforma tecnológica adoptada

| Tecnología | Versión | Rol | Driver |
|-----------|---------|-----|--------|
| Redis Community | 7.x | Caché de productos, clasificaciones, cosecheros, parámetros | Rendimiento, disponibilidad |
| PostgreSQL | 16.x | Base de datos relacional ACID transaccional | Confiabilidad, seguridad |
| SendGrid API | v3 | Notification Gateway — alertas por correo | Usabilidad, confiabilidad |
| Spring Cloud Config | Latest | Catálogo de parámetros externalizado | Cap. ser administrado |
| Strapi Community | 5.x | Catálogo de mensajes y notificaciones | Usabilidad |
| OpenTelemetry + Grafana | Latest | Observabilidad: logs, métricas, trazas | Disponibilidad, soporte |
| GitHub Actions | Latest | CI/CD pipeline automatizado | Cap. ser desplegado |
| Docker + Docker Compose | Latest | Contenedores para todos los servicios | Cap. ser desplegado |
| Springdoc OpenAPI / Swagger UI | 2.x | Documentación automática de API | Usabilidad, cap. ser probado |
| Spring Security + Auth0 RBAC | 6.x | Autorización por rol en cada endpoint | Seguridad, confiabilidad |

### 7.2 Estilos y patrones arquitectónicos adoptados

#### Estilo 1 — Arquitectura Hexagonal

**Problema:** La lógica de negocio (cálculo de comisiones, validación de stock, creación de lotes) no debe depender de frameworks, bases de datos ni servicios externos.

**Solución:** Backend organizado en paquetes `domain` (entidades y enumeraciones del negocio sin dependencias externas), `application` (puertos de entrada/salida y casos de uso), `features` (implementaciones por funcionalidad), `infrastructure` (adaptadores REST, JPA, Redis, SendGrid) y `crosscutting` (excepciones, helpers, catálogos).

#### Estilo 2 — API REST

**Problema:** El frontend debe comunicarse con el backend de forma estándar sin acoplamiento tecnológico.

**Solución:** Backend expone todos sus módulos como endpoints REST con respuestas JSON, documentados automáticamente con OpenAPI 3.0.

#### Estilo 3 — Seguridad centralizada con RBAC

**Problema:** Tres roles con accesos diferenciados: administrador de bodega, propietario, administrador del sistema.

**Solución:** Spring Security intercepta cada solicitud, valida el JWT de Auth0 y verifica permisos mediante `@PreAuthorize` en cada controlador REST.

#### Estilo 4 — SPA con React + TypeScript

**Problema:** Interfaz fluida para registro de múltiples entradas y salidas consecutivas sin recargar página.

**Solución:** SPA con React 19 + TypeScript + React Router DOM + Vite + Tailwind CSS.

#### Estilo 5 — Observabilidad centralizada

**Problema:** Errores en producción difíciles de detectar sin instrumentación adecuada.

**Solución:** OpenTelemetry instrumenta el backend. Grafana + Loki + Tempo visualizan dashboards, logs y trazas en tiempo real.

#### Estilo 6 — Configuración externalizada

**Problema:** Cambios en valores de comisión o umbrales requieren modificar código y redesplegar.

**Solución:** Spring Cloud Config + catálogos Strapi permiten ajustar parámetros sin tocar el código.

#### Estilo 7 — Gestión externalizada de secretos

**Problema:** Credenciales en código fuente representan riesgo grave de seguridad.

**Solución:** HashiCorp Vault almacena todas las credenciales sensibles, accesibles en tiempo de ejecución con rotación segura sin redespliegue.

---

## 8. Justificación alternativa de solución

### 8.1 Justificación

La alternativa seleccionada combina Spring Boot + PostgreSQL + Docker + Auth0 + Kong Gateway + Redis y servicios complementarios open source/freemium porque:

1. **Alineación con restricciones técnicas:** Spring Boot, PostgreSQL y prácticas DevOps ya eran requisitos del proyecto
2. **Costo cero o mínimo:** todos los componentes tienen licencia open source o plan gratuito suficiente para el volumen esperado
3. **Cobertura de atributos de calidad:** PostgreSQL ACID cubre confiabilidad, Docker cubre disponibilidad, Spring Security + Auth0 cubren seguridad, Redis cubre rendimiento
4. **Viabilidad para el equipo:** stack familiar con abundante documentación y comunidad activa

### 8.2 Ventajas

1. Costo total prácticamente cero para el volumen de operación esperado
2. Stack alineado con las restricciones técnicas definidas
3. Robustez transaccional de PostgreSQL garantiza integridad del inventario
4. Auth0 elimina la necesidad de implementar autenticación propia
5. Docker Compose permite levantar todo el entorno con un único comando
6. GitHub Actions integrado nativamente sin infraestructura CI/CD adicional
7. Todos los componentes tienen compatibilidad probada con Spring Boot

### 8.3 Desventajas

1. **Curva de aprendizaje:** integración de Auth0 + Kong + Vault + Redis + OpenTelemetry requiere tiempo de configuración
2. **Dependencia de SaaS:** Auth0 y SendGrid dependen de la disponibilidad de terceros
3. **Complejidad operativa:** 10+ servicios en Docker Compose puede ser desafiante sin experiencia DevOps
4. **Límites del plan gratuito:** Auth0 (25.000 MAU) y SendGrid (100 emails/día) podrían requerir migración a planes pagos
5. **HashiCorp Vault:** configuración inicial no trivial para producción

---

## 9. Vistas de arquitectura del sistema

### 9.1 Vista Funcional

#### 9.1.1 Visión

![Visión AGROBODEGA](diagramas/04_vision.png)

#### 9.1.2 Project Canvas

![Project Canvas AGROBODEGA](diagramas/05_project_canvas.png)

#### 9.1.3 Mapa de impacto

![Mapa de Impacto AGROBODEGA](diagramas/12_mapa_impacto.png)

---

### 9.3 Vista de Despliegue

#### 9.3.1 Diagrama de componentes

Un diagrama de componentes muestra los artefactos, bibliotecas y dependencias que conforman el sistema y las relaciones entre ellos. En AGROBODEGA permite comprender las dependencias tecnológicas de cada artefacto y validar la coherencia entre la arquitectura definida y la implementación real.

##### Backend AGROBODEGA

El Backend es el núcleo de lógica de negocio. Centraliza el procesamiento de entradas y salidas de inventario, gestión de lotes, cobros por comisión, gastos operativos y reportes de rentabilidad. Implementado como Spring Boot sobre Java 26, expone una API REST consumida por el Frontend a través del Kong Gateway, con Spring Security + JWT de Auth0.

![Diagrama de Componentes Backend](diagramas/06_componentes_backend.png)

**Documentación:** El componente principal `AGROBODEGA` (`«jar»`) se ejecuta sobre el runtime Java 26 (`«jre»`) e integra:

| Dependencia | Versión | Rol |
|-------------|---------|-----|
| Spring Boot | 3.3.5 | Contenedor de aplicación y autoconfiguración |
| Spring JPA | 3.3.5 | Persistencia mediante Hibernate + PostgreSQL JDBC |
| Spring Web | 3.3.5 | Endpoints REST y procesamiento HTTP |
| Spring Security | 6.x | Validación de token JWT y reglas RBAC |
| Spring Validation | 3.3.5 | Validación de datos de entrada |
| PostgreSQL Local | 16.x | Base de datos relacional ACID — fuente de verdad |
| Springdoc OpenAPI / Swagger UI | 2.6.0 | Documentación automática OpenAPI 3.0 |
| REST Client — Kong Gateway | — | Punto de entrada único que consume la API REST |
| Spring Framework | — | Base común del ecosistema Spring |

##### Frontend AGROBODEGA

El Frontend es la interfaz web para administrador y propietario. Implementado como SPA (Single Page Application) con React 18 + TypeScript + Vite + Tailwind CSS. Se comunica exclusivamente con el Backend a través del Kong Gateway mediante HTTPS.

![Diagrama de Componentes Frontend](diagramas/07_componentes_frontend.png)

**Documentación:** El componente principal `agrobodega-frontend v1.0.0` (`«spa»`) integra:

| Dependencia | Versión | Tipo | Rol |
|-------------|---------|------|-----|
| TypeScript | 5.9.3 | `«lenguaje»` | Tipado estático |
| Vite | 7.1.12 | `«framework»` | Build y servidor de desarrollo |
| PostCSS | 2.8.0 | `«development_tool»` | Procesador CSS en build |
| TailwindCSS | 3.3.2 | `«ui_library»` | Framework de utilidades CSS |
| React | 19.1.0 | `«framework»` | Biblioteca principal de la SPA |
| React Router DOM | 6.11.2 | `«routing»` | Navegación y guards de autenticación |
| Axios | 1.13.1 | `«library»` | Cliente HTTP hacia el Backend |
| Auth0 React SDK | 2.8.0 | `«library»` | Autenticación, JWT y sesión de usuario |
| lucide-react | latest | `«library»` | Iconos vectoriales reutilizables |
| ESLint | 2.8.0 | `«development_tool»` | Análisis estático de TypeScript |
| Vercel | 48.6.0 | `«PaaS»` | Hosting estático en producción |

---

#### 9.3.2 Diagrama de paquetes

Un diagrama de paquetes organiza los módulos del sistema en grupos lógicos según responsabilidades y dependencias. En AGROBODEGA permite visualizar la organización de capas del Backend y la estructura modular del Frontend.

##### Backend AGROBODEGA

El Backend organiza el código fuente bajo `com.agrobodega` siguiendo arquitectura en capas, separando dominio, aplicación, infraestructura y configuración para reducir acoplamiento y facilitar pruebas.

![Diagrama de Paquetes Backend](diagramas/08_paquetes_backend.png)

**Documentación:**

| Paquete | Contenido | Dependencias |
|---------|-----------|-------------|
| `domain` | `entity` (Lot, EntryMovement, ExitMovement, ProductBase, Farmer, Trader, Alert, Parameter...) y `enums` (Role, ChargeType, AlertType, AlertStatus) | **Ninguna** — núcleo puro |
| `application` | `dto` (objetos de transferencia entrada/salida) y `service` (UserService, ProductService, InventoryService, ThirdPartyService, ExpenseService, ReportService, AlertService) | `domain`, `infrastructure.repository` |
| `config` | Configuración de Spring Security, CORS y beans transversales | `application.service`, `infrastructure.controller` |
| `infrastructure` | `controller` (REST), `exception` (GlobalExceptionHandler), `repository` (Spring Data JPA → PostgreSQL) | `application`, `domain` |

##### Frontend AGROBODEGA

El Frontend organiza el código bajo la raíz `agrobodega` separando configuración, presentación, navegación y comunicación en módulos independientes.

![Diagrama de Paquetes Frontend](diagramas/09_paquetes_frontend.png)

**Documentación:**

| Módulo | Descripción |
|--------|-------------|
| `config` | Variables de entorno, configuración base de Axios y constantes globales |
| `styles` | Estilos globales y configuración de Tailwind CSS |
| `html struct` | Estructura HTML raíz de la SPA y punto de montaje de React |
| `pages` | Páginas por dominio: `dashboard` · `terceros` · `productos` · `inventario` · `finanzas` |
| `Api Service` | Servicios HTTP con Axios hacia el Backend vía Kong Gateway |
| `utils` | Funciones utilitarias: formateo de fechas, cálculos, validaciones |
| `navegation` | React Router DOM: rutas y guards de autenticación |
| `users` | Autenticación con Auth0, manejo del JWT y estado del usuario |

---

#### 9.4 Diagrama de secuencia

Un diagrama de secuencia muestra el intercambio de mensajes entre componentes a lo largo del tiempo para ejecutar una funcionalidad específica. En AGROBODEGA permite comprender cómo interactúan Frontend y Backend en la ejecución de un caso de uso.

##### Backend AGROBODEGA

Muestra el flujo de ejecución interno de Spring Boot para cualquier caso de uso, evidenciando cómo las capas interactúan de forma ordenada y desacoplada.

![Diagrama de Secuencia Backend](diagramas/10_secuencia_backend.png)

**Documentación:**

| Participante | Rol | Mensajes |
|-------------|-----|---------|
| `Controller` | Recibe la petición HTTP, valida JWT y delega | `1. execute(dto)` → Interactor |
| `Interactor` | Inicia el caso de uso, transforma DTO a dominio | `2. execute(domain)` → UseCaseImpl |
| `UseCaseImpl` | Ejecuta la lógica de negocio | `3.1 execute(entity)` → Persistence · `3.2 execute(dto)` → External Service (opt) |
| `Persistence` | Opera sobre PostgreSQL mediante JPA | `return (entity/void)` → UseCaseImpl |
| `External Service` | Servicio externo opcional (Auth0, Vault, Config) | `return (dto/void)` → UseCaseImpl |

La respuesta sube en cascada: `UseCaseImpl → Interactor → Controller → Cliente`

##### Frontend AGROBODEGA

Muestra el flujo completo de una interacción del usuario desde el evento inicial hasta la actualización de la interfaz.

![Diagrama de Secuencia Frontend](diagramas/11_secuencia_frontend.png)

**Documentación:**

| Paso | Mensaje | De → Hacia |
|------|---------|-----------|
| 1 | `click` | Usuario → Página |
| 2 | `submit(dto)` | Página → Componente React |
| 3 | `validarCampos(dto)` | Componente React → *(auto-llamada interna)* |
| 4 | `[válido]` | Resultado de validación interna |
| 5 | `registrar(dto)` | Componente React → Service |
| 6 | `POST /api` | Service → Backend API REST (vía Kong Gateway) |
| 7 | `Response` | Backend API REST → Service |
| 8 | `Respuesta` | Service → Componente React |
| 9 | `Actualizar UI` | Componente React → Página |
| 10 | `Mensaje` | Página → Usuario |

---

*Documento generado para la asignatura Ingeniería de Software II — Universidad — 2026*
